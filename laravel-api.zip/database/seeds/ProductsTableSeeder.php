<?php

use App\Compination;
use App\Product;
use Illuminate\Database\Seeder;

class ProductsTableSeeder extends Seeder
{

    public function __construct()
    {
        $this->faker = Faker\Factory::create();
    }

    public function run()
    {
        DB::table('products')->delete();

        for ($i = 0; $i <= 100; $i++) {
            $product = new Product;
            $product->name = $this->faker->sentence($this->faker->numberBetween(4, 11));
            $product->sku = ucwords($this->faker->randomLetter()) . ucwords($this->faker->randomLetter()) . $this->faker->randomNumber(5);
            $product->status = $this->faker->numberBetween(0, 1);
            $product->price = $this->faker->randomFloat();
            $product->short_description = $this->faker->sentence($this->faker->numberBetween(10, 300));
            $product->description = $this->faker->sentence($this->faker->numberBetween(100, 1000));


            $compination = new Compination();
            $compination->sku = ucwords($this->faker->randomLetter()) . ucwords($this->faker->randomLetter()) . $this->faker->randomNumber(5);
            $compination->price = $this->faker->randomFloat();
            $product->compoination()->save($compination);

            $compination_attibute = new CompinationAttribute;

            //$compination_attibute->attribute
            //$compination_attibute->attribute_value

        }
    }

}
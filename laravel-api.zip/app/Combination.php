<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Compination extends Model
{

    public function attributes()
    {
        return $this->hasMany('App\CompinationAttribute');
    }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{

    public function compinations()
    {
        return $this->hasMany('App\Compination');
    }


}
